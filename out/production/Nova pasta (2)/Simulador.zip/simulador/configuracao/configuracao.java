package simulador.configuracao;

/**
 * Guarda os números importantes para o simulador de coleta de lixo funcionar.
 * <p>
 * Esta classe tem valores fixos, como tempos, quantidades de lixo e horários, usados em todo o sistema.
 */
public class configuracao {

    // ==================== TEMPOS DE TRABALHO ====================

    /**
     * Minutos para descarregar 1 tonelada de lixo.
     */
    public static final int TEMPO_DESCARGA_POR_TONELADA = 3;

    /**
     * Minutos para coletar 1 tonelada de lixo.
     */
    public static final int TEMPO_COLETA_POR_TONELADA = 10;

    // = TEMPO DE VIAGENS DOS CAMINHÕES

    /**
     * Tempo mínimo de viagem em horários de muito trânsito (em minutos).
     */
    public static final int TEMPO_MIN_PICO = 20;

    /**
     * Tempo máximo de viagem em horários de muito trânsito (em minutos).
     */
    public static final int TEMPO_MAX_PICO = 60;

    /**
     * Tempo mínimo de viagem em horários tranquilos (em minutos).
     */
    public static final int TEMPO_MIN_FORA_PICO = 20;

    /**
     * Tempo máximo de viagem em horários tranquilos (em minutos).
     */
    public static final int TEMPO_MAX_FORA_PICO = 35;

    /**
     * Quantidade máxima de viagens por dia para caminhões pequenos.
     */
    public static final int MAX_VIAGENS_DIARIAS_CAMINHAO_PEQUENO = 4;

    // =GERAÇÃO DE LIXO POR ZONA

    /**
     * Menor quantidade de lixo gerada por dia na zona Sul (em toneladas).
     */
    public static final int LIXO_MIN_SUL = 20;

    /**
     * Maior quantidade de lixo gerada por dia na zona Sul (em toneladas).
     */
    public static final int LIXO_MAX_SUL = 40;

    /**
     * Menor quantidade de lixo gerada por dia na zona Norte (em toneladas).
     */
    public static final int LIXO_MIN_NORTE = 15;

    /**
     * Maior quantidade de lixo gerada por dia na zona Norte (em toneladas).
     */
    public static final int LIXO_MAX_NORTE = 30;

    /**
     * Menor quantidade de lixo gerada por dia na zona Centro (em toneladas).
     */
    public static final int LIXO_MIN_CENTRO = 10;

    /**
     * Maior quantidade de lixo gerada por dia na zona Centro (em toneladas).
     */
    public static final int LIXO_MAX_CENTRO = 20;

    /**
     * Menor quantidade de lixo gerada por dia na zona Leste (em toneladas).
     */
    public static final int LIXO_MIN_LESTE = 15;

    /**
     * Maior quantidade de lixo gerada por dia na zona Leste (em toneladas).
     */
    public static final int LIXO_MAX_LESTE = 25;

    /**
     * Menor quantidade de lixo gerada por dia na zona Sudeste (em toneladas).
     */
    public static final int LIXO_MIN_SUDESTE = 18;

    /**
     * Maior quantidade de lixo gerada por dia na zona Sudeste (em toneladas).
     */
    public static final int LIXO_MAX_SUDESTE = 35;



    /**
     * Aumento do tempo de viagem em horários de muito trânsito.
     */
    public static final double MULTIPLICADOR_TEMPO_PICO = 1.5;

    /**
     * Tempo normal de viagem em horários tranquilos.
     */
    public static final double MULTIPLICADOR_TEMPO_FORA_PICO = 1.0;

    // ==================== HORÁRIOS DE TRÂNSITO ====================

    /**
     * Hora de início do trânsito intenso pela manhã.
     */
    public static final int HORA_INICIO_PICO_MANHA = 7;

    /**
     * Hora de fim do trânsito intenso pela manhã.
     */
    public static final int HORA_FIM_PICO_MANHA = 9;

    /**
     * Hora de início do trânsito intenso à tarde.
     */
    public static final int HORA_INICIO_PICO_TARDE = 17;

    /**
     * Hora de fim do trânsito intenso à tarde.
     */
    public static final int HORA_FIM_PICO_TARDE = 19;

    /**
     * Verifica se uma hora está em período de muito trânsito.
     *
     * @param hora Hora do dia (0 a 23)
     * @return Verdadeiro se for horário de pico, falso se não for
     */
    public static boolean isHorarioDePico(int hora) {
        return (hora >= HORA_INICIO_PICO_MANHA && hora < HORA_FIM_PICO_MANHA)
                || (hora >= HORA_INICIO_PICO_TARDE && hora < HORA_FIM_PICO_TARDE);
    }

    /**
     * Não permite criar objetos desta classe, pois ela só guarda valores fixos.
     */
    private configuracao() {
        // Impede a criação de objetos
    }
}