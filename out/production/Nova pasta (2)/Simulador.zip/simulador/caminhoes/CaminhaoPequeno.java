package simulador.caminhoes;

import estruturas.lista.Lista;
import simulador.eventos.EventoGerarCaminhaoGrande;
import simulador.zona.Zona;

/**
 * Um caminhão pequeno que pega lixo nas zonas da cidade.
 * <p>
 * Cada caminhão tem um número único, um limite de carga, um número de viagens por dia
 * e uma lista de zonas para visitar. Ele segue a lista, coletando lixo até encher ou
 * acabar as viagens.
 */
public class CaminhaoPequeno {

    private String id;
    private int capacidadeMaxima;
    private int cargaAtual;
    private int numeroDeViagensDiarias;

    private Lista<Zona> rota;
    private int indiceRota = 0;

    private Zona zonaAlvo;
    private EventoGerarCaminhaoGrande eventoAgendado;

    /**
     * Cria um caminhão pequeno com um número, limite de carga, viagens diárias e zonas para visitar.
     *
     * @param id Número único do caminhão
     * @param capacidadeMaxima Quantidade máxima de lixo que pode carregar (em toneladas)
     * @param numeroDeViagensDiarias Quantas viagens o caminhão pode fazer por dia
     * @param rota Lista de zonas que o caminhão vai visitar, na ordem
     */
    public CaminhaoPequeno(String id, int capacidadeMaxima, int numeroDeViagensDiarias, Lista<Zona> rota) {
        this.id = id;
        this.capacidadeMaxima = capacidadeMaxima;
        this.numeroDeViagensDiarias = numeroDeViagensDiarias;
        this.cargaAtual = 0;
        this.rota = rota;
        this.indiceRota = 0;
        this.zonaAlvo = rota.getValor(0); // Começa na primeira zona da lista
    }

    // ========== INFORMAÇÕES BÁSICAS ==========

    /**
     * Mostra o número único do caminhão.
     *
     * @return O número do caminhão
     */
    public String getId() {
        return id;
    }

    /**
     * Mostra quantas toneladas o caminhão pode carregar no total.
     *
     * @return Limite de carga em toneladas
     */
    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    /**
     * Mostra quantas toneladas de lixo o caminhão está carregando agora.
     *
     * @return Quantidade de lixo atual em toneladas
     */
    public int getCargaAtual() {
        return cargaAtual;
    }

    /**
     * Mostra quantas viagens o caminhão ainda pode fazer hoje.
     *
     * @return Número de viagens restantes
     */
    public int getNumeroDeViagensDiarias() {
        return numeroDeViagensDiarias;
    }

    /**
     * Mostra a zona onde o caminhão está trabalhando agora (usado em partes antigas do sistema).
     *
     * @return Zona atual do caminhão
     */
    public Zona getZonaAlvo() {
        return zonaAlvo;
    }

    // ========== CONTROLE DA ROTA ==========

    /**
     * Mostra a zona atual na lista de zonas que o caminhão está visitando.
     *
     * @return Zona atual da lista
     */
    public Zona getZonaAtualDaRota() {
        return rota.getValor(indiceRota);
    }

    /**
     * Muda para a próxima zona na lista, se houver.
     * <p>
     * Também atualiza a zona atual do caminhão.
     */
    public void avancarParaProximaZona() {
        if (indiceRota < rota.getTamanho() - 1) {
            indiceRota++; // Avança na lista
            this.zonaAlvo = rota.getValor(indiceRota); // Atualiza a zona atual
        }
    }

    /**
     * Verifica se o caminhão ainda tem zonas para visitar na lista.
     *
     * @return Verdadeiro se há mais zonas, falso se acabou
     */
    public boolean temMaisZonasNaRota() {
        return indiceRota < rota.getTamanho() - 1;
    }

    /**
     * Mostra a lista completa de zonas que o caminhão deve visitar.
     *
     * @return Lista de zonas
     */
    public Lista<Zona> getRota() {
        return rota;
    }

    /**
     * Escolhe a próxima zona com lixo para o caminhão visitar.
     *
     * @return Verdadeiro se encontrou uma zona com lixo, falso se todas estão limpas
     */
    public boolean atualizarProximaZonaAlvo() {
        int tentativas = rota.getTamanho(); // Evita ficar preso em um loop

        for (int i = 0; i < tentativas; i++) {
            indiceRota = (indiceRota + 1) % rota.getTamanho(); // Avança circularmente
            Zona proximaZona = rota.getValor(indiceRota);

            if (!proximaZona.estaLimpa()) {
                zonaAlvo = proximaZona; // Define a nova zona
                System.out.println("[CAMINHÃO " + id + "] Redirecionado para zona " + zonaAlvo.getNome());
                return true;
            }
        }
        return false;
    }

    /**
     * Muda a zona atual para a próxima da lista, voltando ao início se acabar.
     */
    public void atualizarZonaAlvo() {
        if (rota == null || rota.getTamanho() == 0) return;

        indiceRota++; // Avança na lista
        if (indiceRota >= rota.getTamanho()) {
            indiceRota = 0; // Volta ao início
        }

        zonaAlvo = rota.getValor(indiceRota); // Atualiza a zona atual
    }

    /**
     * Define uma nova zona para o caminhão visitar, ignorando a lista original.
     * <p>
     * Usado quando o sistema escolhe uma zona mais importante.
     *
     * @param novaZona Zona nova para o caminhão
     */
    public void definirZonaAlvo(Zona novaZona) {
        this.zonaAlvo = novaZona; // Muda a zona atual
    }

    // ========== COLETA DE LIXO ==========

    /**
     * Tenta pegar uma quantidade de lixo na zona.
     *
     * @param quantidade Quantidade de lixo para pegar (em toneladas)
     * @return Verdadeiro se conseguiu pegar, falso se o caminhão ficaria muito cheio
     */
    public boolean coletar(int quantidade) {
        if (cargaAtual + quantidade <= capacidadeMaxima) {
            cargaAtual += quantidade; // Adiciona o lixo
            System.out.println("[CAMINHÃO " + id + "] Coletou " + quantidade + " toneladas");
            return true;
        }
        System.out.println("[CAMINHÃO " + id + "] Carga máxima atingida.");
        return false;
    }

    /**
     * Esvazia todo o lixo do caminhão.
     */
    public void descarregar() {
        this.cargaAtual = 0; // Zera a carga
    }

    /**
     * Verifica se o caminhão pode fazer mais viagens hoje.
     *
     * @return Verdadeiro se ainda tem viagens, falso se acabou
     */
    public boolean podeRealizarNovaViagem() {
        return numeroDeViagensDiarias > 0;
    }

    /**
     * Marca que o caminhão fez uma viagem, diminuindo o número de viagens restantes.
     */
    public void registrarViagem() {
        if (numeroDeViagensDiarias > 0) {
            numeroDeViagensDiarias--; // Reduz o contador
            System.out.println("[CAMINHÃO " + id + "] " + numeroDeViagensDiarias + " VIAGENS RESTANTES");
        }
    }

    // ========== EVENTO DE CAMINHÃO GRANDE ==========

    /**
     * Mostra o evento ligado ao caminhão grande, se houver.
     *
     * @return Evento de criação de caminhão grande, ou null se não tiver
     */
    public EventoGerarCaminhaoGrande getEventoAgendado() {
        return eventoAgendado;
    }

    /**
     * Define um evento de criação de caminhão grande para o caminhão.
     *
     * @param eventoAgendado Evento a ser ligado
     */
    public void setEventoAgendado(EventoGerarCaminhaoGrande eventoAgendado) {
        this.eventoAgendado = eventoAgendado; // Vincula o evento
    }
}