package simulador.estacoes;

import estruturas.filas.Fila;
import simulador.caminhoes.CaminhaoGrande;
import simulador.caminhoes.CaminhaoPequeno;
import simulador.configuracao.configuracao;
import simulador.eventos.AgendaEventos;
import simulador.eventos.EventoColeta;
import simulador.eventos.EventoGerarCaminhaoGrande;
import simulador.util.GerenciadorTempo;

/**
 * Gerencia uma estação de transferência de lixo, recebendo caminhões pequenos,
 * armazenando-os em fila, se necessário, e transferindo carga para um caminhão grande.
 */
public class EstacaoDeTransferencia {
    private String nomeEstacao;
    private CaminhaoGrande caminhaoGrandeAtual;
    private Fila<CaminhaoPequeno> filaCaminhoes = new Fila<>();

    /**
     * Cria uma estação de transferência.
     *
     * @param nomeEstacao Nome da estação
     */
    public EstacaoDeTransferencia(String nomeEstacao) {
        this.nomeEstacao = nomeEstacao;
        this.caminhaoGrandeAtual = new CaminhaoGrande();
    }

    /**
     * Cria um novo caminhão grande e descarrega a fila de espera, se houver.
     *
     * @param tempoAtual Tempo atual da simulação (em minutos)
     */
    public void gerarNovoCaminhaoGrande(int tempoAtual) {
        this.caminhaoGrandeAtual = new CaminhaoGrande();
        System.out.println("[ESTAÇÃO " + nomeEstacao + "] Novo caminhão grande criado.");
        descarregarFilaEspera(tempoAtual);
    }

    /**
     * Retorna o nome da estação.
     *
     * @return Nome da estação
     */
    public String getNomeEstacao() {
        return nomeEstacao;
    }

    /**
     * Retorna a fila de caminhões pequenos em espera.
     *
     * @return Fila de caminhões pequenos
     */
    public Fila<CaminhaoPequeno> getFilaCaminhoes() {
        return filaCaminhoes;
    }

    /**
     * Verifica se há um caminhão grande disponível e com capacidade.
     *
     * @return true se o caminhão grande está disponível e não cheio
     */
    public boolean temCaminhaoGrandeDisponivel() {
        return caminhaoGrandeAtual != null && !caminhaoGrandeAtual.estaCheio();
    }

    /**
     * Processa a chegada de um caminhão pequeno, descarregando diretamente ou adicionando à fila.
     *
     * @param caminhao Caminhão pequeno que chegou
     * @param tempoAtual Tempo atual da simulação (em minutos)
     */
    public void receberCaminhaoPequeno(CaminhaoPequeno caminhao, int tempoAtual) {
        // Início da tabela
        System.out.println("+--------------------------------------------------+");
        System.out.println("|          DESCARREGAMENTO NA ESTAÇÃO            |");
        System.out.println("+--------------------------------------------------+");
        System.out.printf("| %-18s | %-28s |%n", "Horário de Chegada", GerenciadorTempo.formatarHorarioSimulado(tempoAtual));
        System.out.printf("| %-18s | %-28s |%n", "Estação", nomeEstacao);
        System.out.printf("| %-18s | %-28s |%n", "Caminhão", caminhao.getId());
        System.out.printf("| %-18s | %-28s |%n", "Status", "Chegada confirmada");

        // Sem caminhão grande ou caminhão grande cheio
        if (caminhaoGrandeAtual == null || caminhaoGrandeAtual.estaCheio()) {
            filaCaminhoes.enqueue(caminhao);
            System.out.printf("| %-18s | %-28d |%n", "Tamanho da Fila", filaCaminhoes.size());

            // Agenda criação de caminhão grande, se não agendado
            if (caminhao.getEventoAgendado() == null) {
                int tempoLimite = tempoAtual + 100;
                EventoGerarCaminhaoGrande evento = new EventoGerarCaminhaoGrande(tempoLimite, this);
                AgendaEventos.adicionarEvento(evento);
                caminhao.setEventoAgendado(evento);
                System.out.printf("| %-18s | %-28s |%n", "Evento Agendado", "Caminhão grande às " + GerenciadorTempo.formatarHorarioSimulado(tempoLimite));
            }
        } else {
            // Descarrega diretamente
            if (caminhao.getEventoAgendado() != null) {
                AgendaEventos.removerEvento(caminhao.getEventoAgendado());
                caminhao.setEventoAgendado(null);
                System.out.printf("| %-18s | %-28s |%n", "Evento Cancelado", "Geração de caminhão grande");
            }

            int carga = caminhao.getCargaAtual();
            int tempoDescarga = carga * configuracao.TEMPO_DESCARGA_POR_TONELADA;

            caminhaoGrandeAtual.receberCarga(carga);
            caminhao.descarregar();

            System.out.printf("| %-18s | %-28s |%n", "Carga Descarregada", carga + " toneladas (Carga: " + caminhao.getCargaAtual() + "/" + caminhao.getCapacidadeMaxima() + ")");
            System.out.printf("| %-18s | %-28s |%n", "Tempo de Descarga", GerenciadorTempo.formatarDuracao(tempoDescarga));
            System.out.printf("| %-18s | %-28s |%n", "Horário de Conclusão", GerenciadorTempo.formatarHorarioSimulado(tempoAtual + tempoDescarga));

            caminhao.registrarViagem();

            if (caminhao.podeRealizarNovaViagem()) {
                int proximoHorario = tempoAtual + tempoDescarga;
                caminhao.atualizarZonaAlvo();
                AgendaEventos.adicionarEvento(new EventoColeta(proximoHorario, caminhao, caminhao.getZonaAlvo()));
                System.out.printf("| %-18s | %-28s |%n", "Próxima Ação", "Volta para coleta");
            } else {
                System.out.printf("| %-18s | %-28s |%n", "Status do Caminhão", "Finalizou atividades do dia");
            }

            if (caminhaoGrandeAtual.estaCheio()) {
                System.out.printf("| %-18s | %-28s |%n", "Caminhão Grande", "Cheio");
                System.out.printf("| %-18s | %-28s |%n", "Ação", "Caminhão Grande " + caminhaoGrandeAtual.getId() + " partiu para aterro");
                caminhaoGrandeAtual.descarregar();
                descarregarFilaEspera(tempoAtual);
            }
        }
        System.out.println("+--------------------------------------------------+");
        System.out.println();
    }

    /**
     * Descarrega caminhões da fila de espera no caminhão grande atual, enquanto houver espaço.
     *
     * @param tempoAtual Tempo atual da simulação (em minutos)
     */
    private void descarregarFilaEspera(int tempoAtual) {
        while (!filaCaminhoes.isEmpty() && !caminhaoGrandeAtual.estaCheio()) {
            CaminhaoPequeno caminhaoFila = filaCaminhoes.poll();

            if (caminhaoFila.getEventoAgendado() != null) {
                AgendaEventos.removerEvento(caminhaoFila.getEventoAgendado());
                caminhaoFila.setEventoAgendado(null);
            }

            int carga = caminhaoFila.getCargaAtual();
            caminhaoGrandeAtual.receberCarga(carga);
            System.out.println("[ESTAÇÃO " + nomeEstacao + "] Caminhão pequeno " + caminhaoFila.getId() + " da fila descarregou " + carga + " toneladas.");
        }
    }
}