package simulador.zona;

import estruturas.lista.Lista;
import simulador.caminhoes.CaminhaoPequeno;
import simulador.estacoes.EstacaoDeTransferencia;

/**
 * Mapeia zonas da cidade às estações de transferência.
 */
public class GerenciadorZonas {

    private static EstacaoDeTransferencia estacaoA;
    private static EstacaoDeTransferencia estacaoB;
    private static Lista<Zona> zonas;
    private static Lista<CaminhaoPequeno> caminhoes;

    /**
     * Configura as estações A (Leste, Norte, Centro) e B (Sul, Sudeste).
     *
     * @param a Estação A
     * @param b Estação B
     */
    public static void configurar(EstacaoDeTransferencia a, EstacaoDeTransferencia b) {
        estacaoA = a;
        estacaoB = b;
    }

    /**
     * Retorna a estação correspondente a uma zona.
     *
     * @param zona Zona a ser verificada
     * @return Estação responsável
     * @throws IllegalArgumentException se a zona for desconhecida
     */
    public static EstacaoDeTransferencia getEstacaoPara(Zona zona) {
        String nome = zona.getNome().toLowerCase();

        if (nome.equals("leste") || nome.equals("norte") || nome.equals("centro")) {
            return estacaoA;
        }

        if (nome.equals("sul") || nome.equals("sudeste")) {
            return estacaoB;
        }

        throw new IllegalArgumentException("Zona desconhecida: " + zona.getNome());
    }

    /**
     * Define a lista de zonas da simulação.
     *
     * @param listaZonas Lista de zonas
     */
    public static void setZonas(Lista<Zona> listaZonas) {
        zonas = listaZonas;
    }

    /**
     * Define a lista de caminhões da simulação.
     *
     * @param listaCaminhoes Lista de caminhões
     */
    public static void setCaminhoes(Lista<CaminhaoPequeno> listaCaminhoes) {
        caminhoes = listaCaminhoes;
    }

    /**
     * Retorna a lista de todas as zonas.
     *
     * @return Lista de zonas
     */
    public static Lista<Zona> getTodasZonas() {
        return zonas;
    }

    /**
     * Retorna os caminhões com viagens disponíveis.
     *
     * @return Lista de caminhões ativos
     */
    public static Lista<CaminhaoPequeno> getCaminhoesAtivos() {
        Lista<CaminhaoPequeno> ativos = new Lista<>();

        for (int i = 0; i < caminhoes.getTamanho(); i++) {
            CaminhaoPequeno caminhao = caminhoes.getValor(i);
            if (caminhao.podeRealizarNovaViagem()) {
                ativos.adicionar(ativos.getTamanho(), caminhao);
            }
        }

        return ativos;
    }
}