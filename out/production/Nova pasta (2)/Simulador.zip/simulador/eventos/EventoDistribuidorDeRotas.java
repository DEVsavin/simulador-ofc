package simulador.eventos;

import estruturas.lista.Lista;
import simulador.caminhoes.CaminhaoPequeno;
import simulador.eventos.AgendaEventos;
import simulador.eventos.EventoColeta;
import simulador.zona.Zona;

/**
 * Distribui zonas entre caminhões pequenos e agenda seus primeiros eventos de coleta.
 */
public class EventoDistribuidorDeRotas {
    /**
     * Cria caminhões pequenos com rotas balanceadas e agenda coletas iniciais.
     *
     * @param zonas Lista de zonas disponíveis
     * @param quantidadeCaminhoes Número de caminhões a criar
     * @param viagensPorCaminhao Número de viagens por caminhão
     * @param capacidadeCaminhao Capacidade de cada caminhão
     * @return Lista de caminhões criados
     */
    public static Lista<CaminhaoPequeno> distribuir(Lista<Zona> zonas, int quantidadeCaminhoes, int viagensPorCaminhao, int capacidadeCaminhao) {
        Lista<CaminhaoPequeno> caminhoes = new Lista<>();
        int quantidadeZonas = zonas.getTamanho();

        for (int i = 0; i < quantidadeCaminhoes; i++) {
            Lista<Zona> rotaCaminhao = new Lista<>();

            // Atribui zonas às viagens do caminhão
            for (int j = 0; j < viagensPorCaminhao; j++) {
                Zona zonaAlvo = zonas.getValor((i + j) % quantidadeZonas);
                rotaCaminhao.adicionar(j, zonaAlvo);
            }

            String id = "C" + (i + 1);
            int capacidade = capacidadeCaminhao; // Capacidade fixa, pode ser parametrizada

            CaminhaoPequeno caminhao = new CaminhaoPequeno(id, capacidade, viagensPorCaminhao, rotaCaminhao);
            caminhoes.adicionar(i, caminhao);

            // Agenda a primeira coleta
            AgendaEventos.adicionarEvento(new EventoColeta(0, caminhao, caminhao.getZonaAlvo()));
        }

        return caminhoes;
    }
}