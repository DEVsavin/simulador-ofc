package simulador.eventos;

import simulador.caminhoes.CaminhaoPequeno;
import simulador.estacoes.EstacaoDeTransferencia;
import simulador.util.TempoDetalhado;
import simulador.util.GerenciadorTempo;
import simulador.zona.GerenciadorZonas;
import simulador.zona.Zona;

/**
 * Evento para deslocar um caminhão pequeno de uma zona à estação de transferência.
 */
public class EventoTransferenciaParaEstacao extends Evento {
    private final CaminhaoPequeno caminhaoPequeno;
    private final Zona zonaOrigem;

    /**
     * Cria um evento de transferência para a estação.
     *
     * @param tempoInicio Tempo de execução (em minutos)
     * @param caminhaoPequeno Caminhão pequeno a ser deslocado
     * @param zonaOrigem Zona de origem do caminhão
     */
    public EventoTransferenciaParaEstacao(int tempoInicio, CaminhaoPequeno caminhaoPequeno, Zona zonaOrigem) {
        super(tempoInicio);
        this.caminhaoPequeno = caminhaoPequeno;
        this.zonaOrigem = zonaOrigem;
    }

    /**
     * Retorna uma representação textual do evento.
     *
     * @return String com dados do caminhão, zona de origem e horário
     */
    @Override
    public String toString() {
        return String.format("Transferência | Caminhão: %s | Origem: %s | Horário: %s",
                caminhaoPequeno.getId(),
                zonaOrigem.getNome(),
                GerenciadorTempo.formatarHorarioSimulado(getTempo()));
    }

    /**
     * Executa o deslocamento, calcula o tempo de trajeto e agenda a chegada à estação.
     */
    @Override
    public void executar() {
        // Define a estação de destino
        EstacaoDeTransferencia estacaoDestino = GerenciadorZonas.getEstacaoPara(zonaOrigem);

        // Obtém tempo e carga
        int tempoAtual = getTempo();
        int cargaAtual = caminhaoPequeno.getCargaAtual();

        // Calcula tempo de deslocamento
        TempoDetalhado temposCalculados = GerenciadorTempo.calcularTempoDetalhado(tempoAtual, cargaAtual, true);

        // Exibe detalhes em tabela
        System.out.println("+--------------------------------------------------+");
        System.out.println("|          TRANSFERÊNCIA PARA ESTAÇÃO            |");
        System.out.println("+--------------------------------------------------+");
        System.out.printf("| %-18s | %-28s |%n", "Horário Inicial", GerenciadorTempo.formatarHorarioSimulado(tempoAtual));
        System.out.printf("| %-18s | %-28s |%n", "Caminhão", caminhaoPequeno.getId());
        System.out.printf("| %-18s | %-28s |%n", "Estação Destino", estacaoDestino.getNomeEstacao());
        System.out.printf("| %-18s | %-28s |%n", "Tempo de Trajeto", GerenciadorTempo.formatarDuracao(temposCalculados.tempoDeslocamento));
        if (temposCalculados.tempoExtraCarregado > 0) {
            System.out.printf("| %-18s | %-28s |%n", "Tempo Extra Carga", GerenciadorTempo.formatarDuracao(temposCalculados.tempoExtraCarregado));
        }
        System.out.printf("| %-18s | %-28s |%n", "Tempo Total", GerenciadorTempo.formatarDuracao(temposCalculados.tempoTotal));
        System.out.printf("| %-18s | %-28s |%n", "Horário de Chegada", GerenciadorTempo.formatarHorarioSimulado(tempoAtual + temposCalculados.tempoTotal));
        System.out.println("+--------------------------------------------------+");
        System.out.println();

        // Agenda chegada à estação
        AgendaEventos.adicionarEvento(
                new EventoEstacaoTransferencia(
                        tempoAtual + temposCalculados.tempoTotal,
                        estacaoDestino,
                        caminhaoPequeno
                )
        );
    }
}