package simulador.eventos;

import simulador.caminhoes.CaminhaoPequeno;
import simulador.util.TempoDetalhado;
import simulador.util.GerenciadorTempo;
import simulador.zona.Zona;

/**
 * Evento para coleta de lixo em uma zona por um caminhão pequeno.
 */
public class EventoColeta extends Evento {
    private CaminhaoPequeno caminhao;
    private Zona zonaAtual;

    /**
     * Cria um evento de coleta.
     *
     * @param tempo Tempo de execução (em minutos)
     * @param caminhao Caminhão pequeno responsável
     * @param zona Zona alvo da coleta
     */
    public EventoColeta(int tempo, CaminhaoPequeno caminhao, Zona zona) {
        super(tempo);
        this.caminhao = caminhao;
        this.zonaAtual = zona;
    }

    /**
     * Retorna uma representação textual do evento.
     *
     * @return String com dados do caminhão, zona e horário
     */
    @Override
    public String toString() {
        return String.format("EventoColeta | Caminhão %s | Zona %s | Horário: %s",
                caminhao.getId(),
                zonaAtual.getNome(),
                GerenciadorTempo.formatarHorarioSimulado(getTempo()));
    }

    /**
     * Executa a coleta de lixo, respeitando a capacidade do caminhão e o lixo disponível.
     * Agenda nova coleta ou transferência para a estação, conforme o caso.
     */
    @Override
    public void executar() {
        int qtdZona = zonaAtual.getLixoAcumulado();

        // Caso 1: Zona sem lixo
        if (qtdZona == 0) {
            System.out.println("  • Zona está limpa. Nenhuma coleta realizada.");

            caminhao.registrarViagem();

            if (caminhao.podeRealizarNovaViagem()) {
                boolean mudouZona = caminhao.atualizarProximaZonaAlvo();

                if (mudouZona) {
                    AgendaEventos.adicionarEvento(new EventoColeta(tempo + 30, caminhao, caminhao.getZonaAlvo()));
                } else {
                    System.out.println("  • Todas as zonas da rota estão limpas.");
                    AgendaEventos.adicionarEvento(new EventoTransferenciaParaEstacao(tempo, caminhao, zonaAtual));
                }
            } else {
                AgendaEventos.adicionarEvento(new EventoTransferenciaParaEstacao(tempo, caminhao, zonaAtual));
            }
            return;
        }

        // Caso 2: Realiza coleta
        boolean coletou = false;
        int totalColetado = 0;

        while (caminhao.podeRealizarNovaViagem() &&
                caminhao.getCargaAtual() < caminhao.getCapacidadeMaxima() &&
                zonaAtual.getLixoAcumulado() > 0) {

            int qtdDisponivelZona = zonaAtual.getLixoAcumulado();
            int espacoRestante = caminhao.getCapacidadeMaxima() - caminhao.getCargaAtual();
            int qtdReal = Math.min(qtdDisponivelZona, espacoRestante);

            // Tabela de log
            String horarioAtual = GerenciadorTempo.formatarHorarioSimulado(tempo);
            System.out.println("+--------------------------------------------------+");
            System.out.println("|                  COLETA DE LIXO                  |");
            System.out.println("+--------------------------------------------------+");
            System.out.printf("| %-18s | %-28s |%n", "Horário Inicial", horarioAtual);
            System.out.printf("| %-18s | %-28s |%n", "Caminhão", caminhao.getId());
            System.out.printf("| %-18s | %-28s |%n", "Zona", zonaAtual.getNome());
            System.out.printf("| %-18s | %-28d |%n", "Viagens Restantes", caminhao.getNumeroDeViagensDiarias());

            coletou = caminhao.coletar(qtdReal);
            if (coletou) {
                zonaAtual.coletarLixo(qtdReal);
                totalColetado += qtdReal;

                System.out.printf("| %-18s | %-28s |%n", "Quantidade Coletada", qtdReal + " toneladas (Carga: " + caminhao.getCargaAtual() + "/" + caminhao.getCapacidadeMaxima() + ")");
            } else {
                System.out.printf("| %-18s | %-28s |%n", "Quantidade Coletada", "Carga máxima atingida");
                break;
            }
        }

        // Agendamento futuro
        if (caminhao.podeRealizarNovaViagem() && coletou) {
            int tempoAtual = tempo;

            // Calcula tempos
            TempoDetalhado tempoDetalhado = GerenciadorTempo.calcularTempoDetalhado(tempoAtual, totalColetado, false);

            // Continuação da tabela
            System.out.printf("| %-18s | %-28s |%n", "Tempo de Coleta", GerenciadorTempo.formatarDuracao(tempoDetalhado.tempoColeta));
            System.out.printf("| %-18s | %-28s |%n", "Tempo de Trajeto", GerenciadorTempo.formatarDuracao(tempoDetalhado.tempoDeslocamento));
            if (tempoDetalhado.tempoExtraCarregado > 0) {
                System.out.printf("| %-18s | %-28s |%n", "Tempo Extra Carga", GerenciadorTempo.formatarDuracao(tempoDetalhado.tempoExtraCarregado));
            }
            System.out.printf("| %-18s | %-28s |%n", "Horário Final", GerenciadorTempo.formatarHorarioSimulado(tempoAtual + tempoDetalhado.tempoTotal));
            System.out.printf("| %-18s | %-28s |%n", "Tempo Total", GerenciadorTempo.formatarDuracao(tempoDetalhado.tempoTotal));
            System.out.println("+--------------------------------------------------+");
            System.out.println();

            // Agenda nova coleta
            AgendaEventos.adicionarEvento(new EventoColeta(tempoAtual + tempoDetalhado.tempoTotal, caminhao, zonaAtual));

        } else {
            // Vai para estação caso não possa mais coletar
            AgendaEventos.adicionarEvento(new EventoTransferenciaParaEstacao(tempo, caminhao, zonaAtual));
        }
    }
}