import estruturas.lista.Lista;
import simulador.caminhoes.CaminhaoPequeno;
import simulador.estacoes.EstacaoDeTransferencia;
import simulador.eventos.AgendaEventos;
import simulador.eventos.EventoDistribuidorDeRotas;
import simulador.util.GerenciadorTempo;
import simulador.zona.GerenciadorZonas;
import simulador.zona.Zona;
import simulador.zona.Zonas;

/**
 * Coordena a simulação de coleta de lixo com zonas, caminhões e estações.
 */
public class Simulador {

    /**
     * Inicia a simulação para um número de dias, configurando zonas, estações, caminhões e eventos.
     *
     * @param dias Número de dias a simular
     */
    public void iniciarSimulacao(int dias) {
        Lista<Zona> zonas = inicializarZonas();

        // Configura estações
        EstacaoDeTransferencia estA = new EstacaoDeTransferencia("A");
        EstacaoDeTransferencia estB = new EstacaoDeTransferencia("B");
        GerenciadorZonas.configurar(estA, estB);
        GerenciadorZonas.setZonas(zonas);

        for (int dia = 1; dia <= dias; dia++) {
            System.out.println();
            System.out.println("---------------- COLETA DIA " + dia + " ------------");

            // Gera lixo nas zonas
            System.out.println("Gerando lixo nas zonas...");
            for (int i = 0; i < zonas.getTamanho(); i++) {
                zonas.getValor(i).gerarLixoDiario();
            }

            // Distribui caminhões
            Lista<CaminhaoPequeno> caminhoes2t = EventoDistribuidorDeRotas.distribuir(zonas, 8, 5, 2);
            Lista<CaminhaoPequeno> caminhoes4t = EventoDistribuidorDeRotas.distribuir(zonas, 5, 3, 4);
            Lista<CaminhaoPequeno> caminhoes8t = EventoDistribuidorDeRotas.distribuir(zonas, 2, 2, 8);

            GerenciadorZonas.setCaminhoes(caminhoes2t);
            GerenciadorZonas.setCaminhoes(caminhoes4t);
            GerenciadorZonas.setCaminhoes(caminhoes8t);

            System.out.println("Iniciando coleta...\n");

            // Processa eventos
            AgendaEventos.processarEventos();

            // Exibe resumo do dia
            int tempoFinal = AgendaEventos.getTempoUltimoEvento();
            System.out.println();
            System.out.println("=========== FIM DO DIA " + dia + " ===========");
            System.out.println("+--------------------------------------------------+");
            System.out.println("|              RESUMO DO DIA " + dia + "                  |");
            System.out.println("+--------------------------------------------------+");
            System.out.printf("| %-18s | %-28s |%n", "Tempo Total", GerenciadorTempo.formatarDuracao(tempoFinal));
            System.out.printf("| %-18s | %-28s |%n", "Horário Encerramento", GerenciadorTempo.formatarHorarioSimulado(tempoFinal));
            for (int i = 0; i < zonas.getTamanho(); i++) {
                Zona zona = zonas.getValor(i);
                System.out.printf("| %-18s | %-28s |%n", "Zona " + zona.getNome(), zona.getLixoAcumulado() + " toneladas");
            }
            System.out.printf("| %-18s | %-28d |%n", "Caminhões de 2t", caminhoes2t.getTamanho());
            System.out.printf("| %-18s | %-28d |%n", "Caminhões de 4t", caminhoes4t.getTamanho());
            System.out.printf("| %-18s | %-28d |%n", "Caminhões de 8t", caminhoes8t.getTamanho());
            System.out.printf("| %-18s | %-28s |%n", "Último Evento", AgendaEventos.getUltimoEventoExecutado() != null ? AgendaEventos.getUltimoEventoExecutado().toString() : "Nenhum");
            System.out.println("+--------------------------------------------------+");
            System.out.println();

            // Reseta eventos para o próximo dia
            AgendaEventos.resetar();
        }

        System.out.println();
        System.out.println("=============== FIM DA SIMULAÇÃO ===============");
    }

    /**
     * Cria a lista de zonas da simulação.
     *
     * @return Lista com zonas Sul, Sudeste, Centro, Leste e Norte
     */
    public Lista<Zona> inicializarZonas() {
        Lista<Zona> zonas = new Lista<>();
        zonas.adicionar(0, Zonas.zonaSul());
        zonas.adicionar(1, Zonas.zonaSudeste());
        zonas.adicionar(2, Zonas.zonaCentro());
        zonas.adicionar(3, Zonas.zonaLeste());
        zonas.adicionar(4, Zonas.zonaNorte());
        return zonas;
    }
}