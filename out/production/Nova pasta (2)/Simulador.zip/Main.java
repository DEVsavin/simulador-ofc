/**
 * Inicia a simulação de coleta de lixo.
 */
public class Main {

    /**
     * Ponto de entrada da aplicação, executa a simulação.
     *
     * @param args Argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        Simulador test = new Simulador();
        test.iniciarSimulacao(3);
    }
}