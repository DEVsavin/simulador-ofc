package estruturas.filas;

import estruturas.lista.No;

/**
 * Fila encadeada (FIFO) com nós duplamente encadeados.
 */
public class FilaEncadeada<T> {
    private No<T> inicio;
    private No<T> fim;
    private int tamanho;

    /**
     * Construtor. Inicializa a fila vazia.
     */
    public FilaEncadeada() {
        this.inicio = null;
        this.fim = null;
        this.tamanho = 0;
    }

    /**
     * Adiciona um elemento no final da fila.
     *
     * @param valor o valor a ser adicionado
     */
    public void enfileirar(T valor) {
        No<T> novoNo = new No<>(valor);

        if (estaVazia()) {
            inicio = novoNo;
            fim = novoNo;
        } else {
            fim.setProx(novoNo);
            novoNo.setPrev(fim);
            fim = novoNo;
        }

        tamanho++;
    }

    /**
     * Remove e retorna o elemento no início da fila.
     *
     * @return o valor removido, ou {@code null} se a fila estiver vazia
     */
    public T desenfileirar() {
        if (estaVazia()) {
            return null;
        }

        No<T> noRemovido = inicio;
        inicio = inicio.getProx();

        if (inicio != null) {
            inicio.setPrev(null);
        } else {
            fim = null;
        }

        tamanho--;
        return noRemovido.getValor();
    }

    /**
     * Retorna o primeiro elemento da fila, sem removê-lo.
     *
     * @return o valor do primeiro elemento, ou {@code null} se a fila estiver vazia
     */
    public T primeiro() {
        if (estaVazia()) {
            return null;
        }

        return inicio.getValor();
    }

    /**
     * Verifica se a fila está vazia.
     *
     * @return {@code true} se a fila estiver vazia, {@code false} caso contrário
     */
    public boolean estaVazia() {
        return tamanho == 0;
    }

    /**
     * Retorna o número de elementos na fila.
     *
     * @return o tamanho da fila
     */
    public int tamanho() {
        return tamanho;
    }
}
